#!/bin/bash
export DEBIAN_FRONTEND=noninteractive;
apt-get upgrade -y --force-yes;
