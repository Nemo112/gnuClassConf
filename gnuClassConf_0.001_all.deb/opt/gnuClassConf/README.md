gnuClassConf
============

Konfigurační a ovládací prostředí pro správu výukových operačních systémů projektu GNUškola

Pro instalaci spusťte příkazy:
make

Výsledek instalace bude v /opt/gnuClassConf

