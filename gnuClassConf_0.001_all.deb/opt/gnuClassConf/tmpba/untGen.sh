#!/bin/bash
umount "/NFSROOT/class/class_shares/test";
rmdir "/NFSROOT/class/class_shares/test";
exit 0;
