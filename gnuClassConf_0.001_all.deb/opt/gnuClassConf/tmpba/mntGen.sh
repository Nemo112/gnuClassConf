#!/bin/bash
mount -o rbind "/root/test" "/NFSROOT/class/class_shares/test" ;
exit 0;
