#!/bin/bash
gksu /opt/gnuClassConf/main.py;
