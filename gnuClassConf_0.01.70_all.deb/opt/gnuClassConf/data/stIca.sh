#!/bin/bash
/usr/bin/ica &
