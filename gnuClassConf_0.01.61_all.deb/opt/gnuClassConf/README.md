gnuClassConf
============

Konfigurační a ovládací prostředí pro správu výukových operačních systémů projektu GNUškola

Pro instalaci spusťte příkazy:
dpkg -i gnuClassConf_0.001_all.deb

Výsledek instalace bude v /opt/gnuClassConf

