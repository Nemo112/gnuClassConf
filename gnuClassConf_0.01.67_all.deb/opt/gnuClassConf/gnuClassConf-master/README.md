gnuClassConf
============

Konfigurační a ovládací prostředí pro správu výukových operačních systémů projektu GNUškola
